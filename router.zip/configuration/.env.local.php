<?php


define('DBHOST','localhost');
define('DATABASE','mylanguage_api');
define('USERNAME','mylanguageapi');
define('PASSWORD','test2023!');
define('WEBPORT','90');
define('CHARSET','utf8_general_ci');
define('COLLATION','utf8_general_ci');
define('PREFIX','');
define ('WEB_ROOT',  '/mylanguage-api/');
define ('ROOT',  '/mylanguage-api/');
define ('ROOT_IMPORT_DATA', 'c:/ampp/htdocs/mylanguage-api/imports/data/');
define ('ROOT_LOG', 'c:/ampp/htdocs/mylanguage-api/logs/');
define ('ROOT_RESOURCES', 'c:/ampp/htdocs/mylanguage-api/resources/');
define ('ROOT_STYLES', 'c:/ampp/htdocs/mylanguage-api/styles/');
define ('ROOT_TEMPLATES', 'c:/ampp/htdocs/mylanguage-api/templates/');
define ('ROOT_TRANSLATIONS', 'c:/ampp/htdocs/mylanguage-api/translations/languages/');
define ('ROOT_VENDOR', 'c:/ampp/htdocs/mylanguage-api/vendor/');
define ('LOG_MODE',  'write_log');

define('ACCEPTABLE_IP', 'http://localhost:9000');

define('DBT_KEY', '3d116e49d7d98c6e20bf0f4a9c88e4cc');
define('BIBLE_BRAIN_KEY', '1462b719-42d8-0874-7c50-905063472458');