# as_text_node (protected)

```php
as_text_node ( string $tag ) : bool
```

Adds a tag as text node.

| Parameter | Description
| --------- | -----------
| `tag`     | The element's tag name.

Returns true on success.