<?php
/* First we will see if we have the pdf of the study you want.
   If not, we will create it
   Then store it
   Then send you the address of the file you can download
*/
$filename =  $languageCodeHL1 .'-'. $languageCodeHL2 .'-'. $lesson .'.pdf';
if (!$file_exists(ROOT_DBS_PDF . $filename)){
    $html = createDbs($languageCodeHL1, $languageCodeHL2, $lesson);
    require_once ROOT_VENDOR .'autoload.php';
    try{
        $mpdf = new \Mpdf\Mpdf([
            'mode' => 'utf-8',
            'orientation' => 'P'
        ]);
        $mpdf->SetDisplayMode('fullpage');
        $mpdf->WriteHTML($html);
        $mpdf->Output(ROOT_DBS_PDF . $filename, 'F');
    } catch (\Mpdf\MpdfException $e) { // Note: safer fully qualified exception name used for catch
        // Process the exception, log, print etc.

    }
    
}
$url = WEBADDRESS_DBS_PDF . $filename;
ReturnDataController::returnData($url);







function createDbs ($languageCodeHL1, $languageCodeHL2, $lesson){
    $dbs = new DbsBilingualTemplateController($languageCodeHL1, $languageCodeHL2, $lesson);

    $dbsReference= new DbsReference();
    $dbsReference->setLesson($lesson);

    $bibleReferenceInfo= new  BibleReferenceInfo();
    $bibleReferenceInfo->setFromEntry($dbsReference->getEntry());
    $testament = $bibleReferenceInfo->getTestament();

    $bible1 = new Bible();
    $bible1->setBestDbsBibleByLanguageCodeHL($languageCodeHL1, $testament);
    $dbs->setBibleOne($bible1);

    $bible2 = new Bible();
    $bible2->setBestDbsBibleByLanguageCodeHL($languageCodeHL2, $testament);
    $dbs->setBibleTwo($bible2);

    $dbs->setPassage($bibleReferenceInfo);
    $dbs->setBilingualTemplate();
    //ReturnDataController::returnData($dbs->getTemplate());
    $html =  $dbs->getTemplate();
}