<?php
echo ('look at getlanguageDetails-46 ');
$test = new BibleBrainLanguageController();
$test->getlanguageDetails('bng');

