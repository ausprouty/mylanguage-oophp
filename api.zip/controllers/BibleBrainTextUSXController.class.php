<?php



class BibleBrainTextUSXController extends BibleBrainPassageController
{
    
}