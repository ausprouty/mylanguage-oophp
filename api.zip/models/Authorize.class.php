<?php
class Authorize{


    static function authorized($post){
        return true;
    }
}