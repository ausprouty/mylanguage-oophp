<?php

$import = new DBSReferenceDatabaseImport();
$import->getLessons();