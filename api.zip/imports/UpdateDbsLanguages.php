<?php

$dbs = new DbsLanguageController();
$dbs->updateDatabase();
echo ('check database');