<?php

$bibles = new BibleGatewayBibleController();
$bibles->import();